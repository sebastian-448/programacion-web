<?php
//paso 1
require "config/conex.php";

//paso 2
$id = $_POST ["txt_id"];

// paso 3

$sql= "DELETE FROM inscripciones WHERE id = ".$id." ";

//echo $sql."<br>";

//paso 4
if($dbh-> query($sql))
{
    echo "eliminacion exitosa";
}else
{
    echo "error al eliminar";
}



?>