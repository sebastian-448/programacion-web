<?php
$valor = $_POST['saldo'];
$valor_enviar = $_POST['valor_enviar'];

//valor inicial : 359000
$valor_enviado = 359000 - $valor_enviar;
$valor = $valor_enviado * 0.004;
$valor_final = $valor_enviado - $valor;

echo "transaccion realizada". "<br>";
echo "comision cobrada: ".$valor."<br>";
echo "saldo restante: ".$valor_final."<br>";

?>