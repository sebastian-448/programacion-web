<?php
$dias = $_POST['dias'];
$tipo_habitacion = $_POST['tipo_habitacion'];
$acompañantes = $_POST['acompañantes'];

if ($acompañantes > 5){
    echo "no puede exceder el maximo de 5 acompañantes";
} else {
    $costo_base = 100000 * $dias;
    $costo_acompañantes = 30000 * $acompañantes * $dias;
    $subtotal = $costo_base + $costo_acompañantes;
    if ($tipo_habitacion == "suite") {
        $subtotal = $subtotal * 1.10; #Add the 10%\%
    }
    
    
    echo "<h2>Detalle de la compra</h2>";
    echo "Dias de estadia: ".$dias . "<br>";
    echo "Tipo de habitacion: ".$tipo_habitacion . "<br>";
    echo "Numero de acompañantes: ".$acompañantes . "<br>";
    echo "Total a pagar: $" .number_format($subtotal). "<br>";    

}


?>